-- Tyler Quayle - Assignment 01, Part 01. 1/13/2014
-- 1.(10 pts.) Get all the data about the countries that are present in the world database

-- Selecting everything from Table Country in DB World
SELECT * From Country