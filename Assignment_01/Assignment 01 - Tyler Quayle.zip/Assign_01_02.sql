-- Tyler Quayle - Assignment 01, Part 02. 1/13/2014
-- 2.(10 pts.) Get all the data about the cities that are present in the world database

-- Selecting everything from Table City in DB World
SELECT * From City